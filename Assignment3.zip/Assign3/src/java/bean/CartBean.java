/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;
import java.sql.*;

/**
 *
 * @author vivia
 */
public class CartBean {
    public static boolean updateCart(ItemBean item, String user) {
        try {
            Connection con = DBBean.getCon();

            // Get all the items for the current user
            PreparedStatement ps = con.prepareStatement("select * from usersitems where username=? and item=?");
            
            ps.setString(1, user);  
            ps.setString(2, item.getName());  
            
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                // If we get a result, that means the user has some items, so, we need to get the current quantity, and add how many
                // they want on this latest request
                double quantity = rs.getDouble("quantity");
                quantity += item.getQuantity();
                PreparedStatement updateStatement = con.prepareStatement("update usersitems set quantity=? where username=? and item=?");
                updateStatement.setDouble(1, quantity);
                updateStatement.setString(2, user);
                updateStatement.setString(3, item.getName());
                updateStatement.execute();
            } else {
                // If we didn't get a result, that means this is the first thing in their cart, so we do an insert
                PreparedStatement insertStatement = con.prepareStatement("insert into usersitems (username, item, quantity) values (?, ?, ?)");
                insertStatement.setString(1, user);
                insertStatement.setString(2, item.getName());
                insertStatement.setDouble(3, item.getQuantity());
                insertStatement.execute();
            }
            
            return true;
        } catch (Exception e) {
            System.out.println(e);
            return false;
        }
    }
    
    public static double getCart(String user) {
        try {
            Connection con = DBBean.getCon();

            // Get the item name and the quantity of that item for the current user
            PreparedStatement ps = con.prepareStatement("select item, quantity from usersitems where username=?");
            
            ps.setString(1, user);
            
            ResultSet rs = ps.executeQuery();
            
            double total = 0.0;          
            while (rs.next()) {
                // For each item that the user has get the price of that item
                ps = con.prepareStatement("select price from items where name=?");
                
                String name = rs.getString("item");
                double quantity = rs.getDouble("quantity");
                
                ps.setString(1, name);
                
                ResultSet item = ps.executeQuery();
                
                // If we get a result (we always should...) get the price of that item multiply by the quantity of that item
                // then add that to the running total
                if (item.next()) {
                    double price = item.getDouble("price");
                    total += (price * quantity);
                }
            }
            
            return total;
        } catch (Exception e) {
            System.out.println(e);
            return 0;
        }
    }
}
