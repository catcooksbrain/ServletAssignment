/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
  
/**
 *
 * @author vivia
 */
public class DBBean {
    private static Connection con = null;
    
    static {  
        String connectionURL = "jdbc:derby://localhost:1527/assignment3";
        
        //ConnectionURL, username and password should be specified in getConnection()
        try {
            con = DriverManager.getConnection(connectionURL, "app", "app");
            System.out.println("Connect successfully ! ");
        } catch (SQLException ex) {
            System.out.println("Connect failed ! ");
            System.out.println(ex);
        }
   }

   public static Connection getCon(){  
       return con;  
   }   
}
