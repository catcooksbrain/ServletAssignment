/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;
import java.sql.*;  
import java.util.ArrayList;

/**
 *
 * @author vivia
 */
public class ItemsBean {
    public static ArrayList<ItemBean> getItems() {
        try {
            Connection con = DBBean.getCon();

            // Get all the available items from the database
            PreparedStatement ps = con.prepareStatement("select * from items");
            ResultSet rs = ps.executeQuery();
            
            ArrayList<ItemBean> items = new ArrayList();
            while (rs.next()) {
                String name = rs.getString("name");
                double price = rs.getDouble("price");
                
                // Add the info about the item to the ItemBean object
                ItemBean item = new ItemBean();
                item.setName(name);
                item.setPrice(price);
                
                // Add the ItemBean object to the list of all items
                items.add(item);
            }
            
            return items;
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }
}
