/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;  
import java.sql.*;  

/**
 *
 * @author vivia
 */
public class LoginDB {
    public static boolean validate(LoginBean bean) {
        boolean status = false;

        try {
            // First connect to the database
            Connection con = DBBean.getCon();  
            
            // check if username and password is in db
            PreparedStatement ps=con.prepareStatement(  
                "select * from users where username=? and password=?");  

            ps.setString(1, bean.getUsername());  
            ps.setString(2, bean.getPassword());  

            ResultSet rs=ps.executeQuery();  
            status=rs.next();  

            System.out.println(status);
        } catch(Exception e) {
            System.out.println("Exception getting users: " + e);
        }  

        return status;  
    } 
}

